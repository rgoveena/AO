package com.ao.aoats.web.driver;

public enum BrowserType {
	CHROME("chrome"), FIREFOX("firefox"), HTMLUNIT("htmlunit"), IE("iexplore");

	/**
	 * Create enum object for value string.
	 * 
	 * @param valStr
	 *            value string for enum object
	 * @return instance of enum object based on value string. default is CHROME, if
	 *         no match found.
	 */
	public static BrowserType init(String valStr) {
		// put default value.
		BrowserType retVal = CHROME;
		// Search for correct enum type
		for (BrowserType currVal : BrowserType.values()) {
			if (currVal.getBrowserString().equalsIgnoreCase(valStr)) {
				retVal = currVal;
			}
		}
		// return from here.
		return retVal;
	}

	/**
	 * This field - browserValue is used for _.
	 */
	private final String browserValue;

	/**
	 * @param browserString
	 */
	BrowserType(String browserString) {
		this.browserValue = browserString;
	}

	/**
	 * @return
	 */
	public String getBrowserString() {
		return this.browserValue;
	}
}
