/**
 * @author Govi Rajagopal
 */

package com.ao.aoats.core;

import java.io.FileInputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

public class ConfigManager {

	/**
	 * This field - init is used for Storing Initialization results.
	 */
	private static boolean init = false;

	/**
	 * 
	 */
	private static Properties properties = new SSConfiguration();

	/**
	 * @param props
	 */
	public static void addFileInProps(Properties props) {
		for (Object key : props.keySet()) {
			ConfigManager.properties.setProperty((String) key, (String) props.get(key));
		}

	}

	/**
	 * @param fileName
	 */
	public static void addFileInProps(String fileName) {
		InputStream file;
		try {
			if (fileName.startsWith("classpath:")) {
				fileName = fileName.replace("classpath:", "");
				file = ClassLoader.getSystemClassLoader().getResourceAsStream(fileName);
			} else {
				file = new FileInputStream(fileName);
			}
			ConfigManager.properties.load(file);
		} catch (Exception e) {
			Log.debug("Can not find Property file [" + fileName + "] And it will be ignored from Property Manager");
			e.printStackTrace();
		}

	}

	/**
	 * @param key
	 * @return
	 */
	public static String get(String key) {
		return ConfigManager.getProperty(key);
	}

	/**
	 * @return
	 */
	public static Map<String, String> getAllPropertiesAsMap() {
		Map<String, String> propMap = new HashMap<String, String>();

		for (String key : ConfigManager.properties.stringPropertyNames()) {
			propMap.put(key, ConfigManager.properties.getProperty(key));
		}

		// return from here.
		return propMap;
	}

	/**
	 * Gets all the property values fetched byConfigManager and returns as map
	 * 
	 * @param frameworkPropertyFileName
	 *            Framework.properties file location
	 * @param cameraPropertyFileName
	 *            Camera.properties file location
	 * @return Map&lt;String, String&gt; of properties
	 */
	public static Map<String, String> getAllPropertiesAsMap(String frameworkPropertyFileName,
			String cameraPropertyFileName) {
		if (ConfigManager.properties.isEmpty()) {
			ConfigManager.addFileInProps(frameworkPropertyFileName);
			ConfigManager.addFileInProps(cameraPropertyFileName);
		}

		Map<String, String> propMap = new HashMap<String, String>();

		for (String key : ConfigManager.properties.stringPropertyNames()) {
			propMap.put(key, ConfigManager.properties.getProperty(key));
		}

		// return from here.
		return propMap;
	}

	/**
	 * @param key
	 * @return
	 */
	public static String getProperty(String key) {
		if (ConfigManager.init == false) {
			ConfigManager.init();
		}

		if (System.getProperty(key) != null) {
			return System.getProperty(key);
		} else {
			return ConfigManager.properties.getProperty(key);
		}
	}

	/**
	 * This method should be overridden from child class; if needs to use different
	 * file set.
	 */
	private static void init() {
		String fileName = "src/main/resource/config/propertySet.properties";
		// set init to true now.
		ConfigManager.init = true;

		try {
			// Load all property files from property set.
			Properties fileSet = new SSConfiguration();
			InputStream file = new FileInputStream(fileName);
			fileSet.load(file);

			int propCnt = Integer.parseInt(fileSet.getProperty("TOTAL_PROP_FILE"));
			for (int i = 1; i <= propCnt; i++) {
				ConfigManager.addFileInProps(fileSet.getProperty("FILE_" + i));
			}

		} catch (Exception e) {
			Log.error("Can not read Property file [" + fileName + "] - ", e);
			e.printStackTrace();
		}

	}

	public static List<String> getAsList(String str, String sep) {
		List<String> retList = new ArrayList<String>();
		if (str != null) {
			for (String val : str.split(sep, -2)) {
				retList.add(val);
			}
		}
		// return from here
		return retList;
	}

	/**
	 * @param key
	 * @param value
	 */
	public static void set(String key, String value) {
		ConfigManager.setProperty(key, value);
	}

	/**
	 * @param key
	 * @param value
	 */
	public static void set(String key, String value, String comment) {
		ConfigManager.setProperty(key, value);
	}

	/**
	 * @param key
	 * @param value
	 */
	public static void setProperty(String key, String value) {
		if (ConfigManager.init == false) {
			ConfigManager.init();
		}
		ConfigManager.properties.setProperty(key, value);
	}
}
