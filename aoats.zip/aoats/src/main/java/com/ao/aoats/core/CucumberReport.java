/**
 * @author Govi Rajagopal
 */

package com.ao.aoats.core;

import com.github.mkolisnyk.cucumber.reporting.CucumberDetailedResults;
import com.github.mkolisnyk.cucumber.reporting.CucumberResultsOverview;

public class CucumberReport {

	private static String outPutDir = ConfigManager.get("output_directory");
	private static String outputName = ConfigManager.get("output_name");
	private static String sourceFile = ConfigManager.get("source_file");

	public static void createCucumberReport() {
		Log.info("Creating Local cucumber results");
		CucumberDetailedResults detailedResults = new CucumberDetailedResults();
		CucumberResultsOverview overView = new CucumberResultsOverview();
		detailedResults.setOutputDirectory(outPutDir);
		detailedResults.setOutputName(outputName);
		detailedResults.setSourceFile(outPutDir + sourceFile);
		detailedResults.setScreenShotLocation("");
		detailedResults.setScreenShotWidth("1000");
		overView.setOutputDirectory(outPutDir);
		overView.setOutputName(outputName);
		overView.setSourceFile(outPutDir + sourceFile);
		try {
			detailedResults.executeDetailedResultsReport(true, false);
			overView.executeFeaturesOverviewReport();
		} catch (Exception e) {
			Log.error("Cannot Create local Cucumber results", e);
			e.printStackTrace();
		}
	}

}
