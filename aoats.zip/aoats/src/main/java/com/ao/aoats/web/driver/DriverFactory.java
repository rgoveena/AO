/**
 * @author Govi Rajagopal
 */
package com.ao.aoats.web.driver;

import java.io.File;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.htmlunit.HtmlUnitDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;

import com.ao.aoats.core.ConfigManager;
import com.ao.aoats.utils.SystemUtils;

public class DriverFactory {
	private static WebDriver driver = null;

	public static WebDriver getDriver() {

		BrowserType browserType = getBrowserType();
		String exePath;
		DesiredCapabilities capabilities = setCapabilities(browserType);

		switch (browserType) {
		case IE:
			// Process for Internet Explorer
			boolean is64bit = SystemUtils.is64Bit();
			boolean is64bitDriver = Boolean.valueOf(ConfigManager.get("use_64_bit_driver"));
			if (is64bit && is64bitDriver) {
				exePath = ConfigManager.get("webdriver.ie.driver.64");
			} else {
				exePath = ConfigManager.get("webdriver.ie.driver.32");
			}
			System.setProperty("webdriver.ie.driver", exePath);
			driver = new InternetExplorerDriver(capabilities);
			break;
		case FIREFOX:
			// Process for Firefox
			driver = new FirefoxDriver(capabilities);
			driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
			break;
		case CHROME:
			// Process for Chrome
			boolean isWindows = SystemUtils.isWindows();
			if (isWindows) {
				exePath = ConfigManager.get("webdriver.chrome.driver");
				System.setProperty("webdriver.chrome.driver", exePath);
			}
			driver = new ChromeDriver(capabilities);
			break;
		case HTMLUNIT:
			// Process for HTML Unit.
			driver = new HtmlUnitDriver(capabilities);
			((HtmlUnitDriver) driver).setJavascriptEnabled(true);
			break;

		}

		return driver;

	}

	private static DesiredCapabilities setCapabilities(BrowserType browserType) {

		DesiredCapabilities capabilities = null;
		switch (browserType) {
		case IE:
			capabilities = setIECapabilities();
			break;
		case FIREFOX:
			capabilities = setFirefoxCapabilities();
			break;
		case CHROME:
			capabilities = DesiredCapabilities.chrome();
			break;
		case HTMLUNIT:
			capabilities = DesiredCapabilities.htmlUnit();
			break;
		default:
			capabilities = DesiredCapabilities.chrome();
			break;
		}
		return capabilities;
	}

	private static DesiredCapabilities setFirefoxCapabilities() {
		DesiredCapabilities capabilities = null;
		try {
			String firefoxProfileTemplate = ConfigManager.get("FF_PROFILE_PATH");

			FirefoxProfile firefoxProfile;

			if ((firefoxProfileTemplate != null) && (!firefoxProfileTemplate.equals("DEFAULT"))) {
				File file = new File(firefoxProfileTemplate);
				if (file.exists()) {

					firefoxProfile = new FirefoxProfile(file);
				} else {
					firefoxProfile = new FirefoxProfile();
				}
			} else {
				firefoxProfile = new FirefoxProfile();
			}

			firefoxProfile.setAssumeUntrustedCertificateIssuer(false);
			firefoxProfile.setAcceptUntrustedCertificates(false);

			capabilities = DesiredCapabilities.firefox();
			capabilities.setCapability(FirefoxDriver.PROFILE, firefoxProfile);

		} catch (Exception e) {
			e.printStackTrace();
		}
		return capabilities;
	}

	private static DesiredCapabilities setIECapabilities() {
		DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
		capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
		capabilities.setJavascriptEnabled(true);

		String version = ConfigManager.getProperty("browser_version");
		if ((version != null) && (!version.isEmpty())) {

			capabilities.setVersion(version);
		}

		return capabilities;
	}

	private static BrowserType getBrowserType() {
		String browser = ConfigManager.get("browser_type");
		return BrowserType.init(browser);

	}

}
