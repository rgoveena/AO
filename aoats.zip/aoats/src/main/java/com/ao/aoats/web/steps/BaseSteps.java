package com.ao.aoats.web.steps;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.ao.aoats.web.driver.SharedDriver;
import com.paulhammant.ngwebdriver.NgWebDriver;

/**
 * @author Govi Rajagopal
 */
public class BaseSteps {

	protected WebDriver driver;
	protected NgWebDriver ngWebDriver;

	public BaseSteps() {
		this.driver = new SharedDriver();
		this.ngWebDriver = new NgWebDriver((JavascriptExecutor) driver);
	}

	public void browserWait(int seconds) {
		// driver.manage().timeouts().implicitlyWait(seconds, TimeUnit.SECONDS);
		try {
			Thread.sleep(seconds * 1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void waitForPageToLoad() {
		WebDriverWait wait = new WebDriverWait(driver, 30);

		wait.until(new ExpectedCondition<Boolean>() {
			public Boolean apply(WebDriver wdriver) {
				return ((JavascriptExecutor) driver).executeScript("return document.readyState").equals("complete");
			}
		});
	}
}
