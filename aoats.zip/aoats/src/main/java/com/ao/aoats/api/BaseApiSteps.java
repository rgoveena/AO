/**
 * @author Govi Rajagopal
 */

package com.ao.aoats.api;

import static com.jayway.restassured.RestAssured.given;

import java.io.File;
import java.io.IOException;

import com.ao.aoats.core.ConfigManager;
import com.ao.aoats.core.Log;
import com.google.common.base.Charsets;
import com.google.common.io.Files;
import com.jayway.restassured.response.Response;
import com.jayway.restassured.specification.RequestSpecification;

public class BaseApiSteps {

	protected RequestSpecification spec = given();
	protected Response response;
	private static String env = ConfigManager.get("ENV") + "_";
	private static String BASE_PATH = ConfigManager.get(env + "base_path");

	public RequestSpecification setupSpec() {

		return spec.auth().preemptive().oauth2(TokenProvider.getAccessToken()).baseUri(BASE_PATH);
	}

	public void resetSpec() {
		spec = given();
	}

	public void resetResponse() {
		response = null;
	}

	public static void setBasePath(String basePath) {
		BASE_PATH = basePath;
	}

	public static String readData(String path) {
		String text = null;
		try {
			text = Files.toString(new File(path), Charsets.UTF_8);
		} catch (IOException e) {
			Log.error("Cannot read  file [" + path + "] - ", e);
		}
		return text;

	}

}
