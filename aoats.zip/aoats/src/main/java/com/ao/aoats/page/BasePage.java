/**
 * @author Govi Rajagopal
 */
package com.ao.aoats.page;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.ao.aoats.core.Log;

public class BasePage {
	protected WebDriver driver;

	public BasePage(WebDriver driver) {
		this.driver = driver;
	}

	public WebElement getDynamicElement(By by, int timeout) {
		WebElement myDynamicElement = null;
		try {
			myDynamicElement = (new WebDriverWait(driver, timeout))
					.until(ExpectedConditions.presenceOfElementLocated(by));
		} catch (Throwable t) {
			Log.error("Error Occured. Element not visible", t);
		}

		return myDynamicElement;
	}

	public WebElement getClickableElement(By by, int timeout) {
		WebElement clickableElement = null;
		try {
			clickableElement = (new WebDriverWait(driver, timeout)).until(ExpectedConditions.elementToBeClickable(by));
		} catch (Throwable t) {
			Log.error("Error Occured. Element not clickable", t);
		}

		return clickableElement;
	}

}
