/**
 * @author Govi Rajagopal
 */
package com.ao.aoats.web.driver;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.events.EventFiringWebDriver;

import com.ao.aoats.core.Log;

public class SharedDriver extends EventFiringWebDriver {

	private static final WebDriver REAL_DRIVER = DriverFactory.getDriver();

	private static final Thread CLOSE_THREAD = new Thread() {
		@Override
		public void run() {
			Log.info("Execution complete. Closing Browser");
			REAL_DRIVER.close();
		}
	};

	static {
		Runtime.getRuntime().addShutdownHook(CLOSE_THREAD);
	}

	public SharedDriver() {
		super(REAL_DRIVER);
	}

	@Override
	public void close() {
		if (Thread.currentThread() != CLOSE_THREAD) {
			throw new UnsupportedOperationException(
					"You shouldn't close this WebDriver. It's shared and will close when the JVM exits.");
		}
		super.close();
	}

}
