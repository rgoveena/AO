/**
 * @author Govi Rajagopal
 */
package com.ao.aoats.web.steps;

import java.awt.Toolkit;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import org.openqa.selenium.Dimension;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.Point;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;

import com.ao.aoats.core.ConfigManager;
import com.ao.aoats.core.Log;

import cucumber.api.Scenario;

public class BaseCucumberHook extends BaseSteps {

	public void takeScreenShot(Scenario scenario) {
		try {
			byte[] screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES);
			scenario.embed(screenshot, "image/png");
			String scId = scenario.getId().replaceAll("[; !@#$%^&*()+=]", "_");
			Log.warn(scId + " - scenario Failed ScreenShot taken");

			String imagefile = ConfigManager.get("output_directory") + scId + ".png";
			FileOutputStream out = new FileOutputStream(imagefile);
			out.write(screenshot);
			out.flush();
			out.close();
		} catch (WebDriverException somePlatformsDontSupportScreenshots) {
			Log.error("Cannot take screen shot", somePlatformsDontSupportScreenshots);
		} catch (FileNotFoundException fne) {
			Log.error("Cannot take screen shot", fne);
		} catch (IOException ioe) {
			Log.error("Cannot take screen shot", ioe);
		}
	}

	public void maximizeScreen(WebDriver driver) {
		java.awt.Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		Point position = new Point(0, 0);
		driver.manage().window().setPosition(position);
		Dimension maximizedScreenSize = new Dimension((int) screenSize.getWidth(), (int) screenSize.getHeight());
		driver.manage().window().setSize(maximizedScreenSize);
	}

}
