/**
 * @author Govi Rajagopal
 */
package com.ao.aoats.utils;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

import com.ao.aoats.core.Log;

public class SystemUtils {

	public static boolean is64Bit() {
		boolean _is64bit = false;

		try {

			ProcessBuilder builder = new ProcessBuilder("cmd.exe", "/c", "wmic OS get OSArchitecture");
			builder.redirectErrorStream(true);
			Process p = builder.start();
			String result = getStringFromInputStream(p.getInputStream());

			if (result.contains("64"))
				_is64bit = true;
		} catch (IOException e) {
			e.printStackTrace();
		}
		return _is64bit;

	}

	private static String getStringFromInputStream(InputStream is) {

		BufferedReader br = null;
		StringBuilder sb = new StringBuilder();

		String line;
		try {

			br = new BufferedReader(new InputStreamReader(is));
			while ((line = br.readLine()) != null) {
				sb.append(line);
			}

		} catch (IOException e) {
			Log.error("Something wrong in reading OS values", e);
		} finally {
			if (br != null) {
				try {
					br.close();
				} catch (IOException e) {
					Log.error("Error closing buffered reader", e);
				}
			}
		}

		return sb.toString();

	}

	public static boolean isWindows() {
		return System.getProperty("os.name").startsWith("Windows");

	}

}
