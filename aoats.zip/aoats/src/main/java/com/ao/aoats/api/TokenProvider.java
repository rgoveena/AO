/**
 * @author Govi Rajagopal
 */

package com.ao.aoats.api;

import static com.jayway.restassured.RestAssured.given;

import com.ao.aoats.core.ConfigManager;
import com.ao.aoats.core.Log;
import com.jayway.restassured.http.ContentType;
import com.jayway.restassured.response.Response;

public class TokenProvider {

	private static String accessToken = null;
	private static Response response = null;
	private static String env = ConfigManager.get("ENV") + "_";
	private static final String TOKEN_URL = ConfigManager.get(env + "token_url");

	public static String getAccessToken() {
		if (null == accessToken) {
			System.setProperty("https.proxyHost", ConfigManager.get("proxy_host"));
			System.setProperty("https.proxyPort", ConfigManager.get("proxy_port"));
			if ("basic".equalsIgnoreCase(ConfigManager.get("oauth_auth_type"))) {

				response = given().auth().preemptive()
						.basic(ConfigManager.get(env + "token_username"), ConfigManager.get(env + "token_password"))
						.contentType(ContentType.URLENC).when().body("grant_type=client_credentials").post(TOKEN_URL);
			} else if ("client".equalsIgnoreCase(ConfigManager.get("oauth_auth_type"))) {
				String body = BaseApiSteps.readData(ConfigManager.get(env + "oauth_request_body"));
				response = given().contentType(ContentType.JSON).when().body(body).post(TOKEN_URL);
			}

			setAccessToken((String) response.path("access_token"));
			Log.info("Access Token : " + (String) response.path("access_token"));
		}

		return accessToken;
	}

	public static void setAccessToken(String accesstoken) {
		TokenProvider.accessToken = accesstoken;
	}

}
